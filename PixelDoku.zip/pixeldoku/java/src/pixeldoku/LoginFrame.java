package pixeldoku;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

/** First screen the player sees: enter a gamer name to begin. */
public class LoginFrame extends JFrame {

    public LoginFrame(PuzzleBank bank) {
        super("PixelDoku - Sign In");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(560, 420);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(new EmptyBorder(30, 30, 30, 30));
        setContentPane(root);

        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0;
        gc.insets = new Insets(12, 0, 12, 0);

        JLabel title = new JLabel("PIXELDOKU", SwingConstants.CENTER);
        title.setFont(Theme.pixelFont(28f));
        title.setForeground(Theme.CRIMSON);
        gc.gridy = 0;
        root.add(title, gc);

        JLabel subtitle = new JLabel("<html><center>a whimsical logic-puzzle quest</center></html>", SwingConstants.CENTER);
        subtitle.setFont(new Font("SansSerif", Font.ITALIC, 14));
        subtitle.setForeground(Theme.TEXT_DARK);
        gc.gridy = 1;
        root.add(subtitle, gc);

        JLabel prompt = new JLabel("Enter your gamer name:");
        prompt.setFont(Theme.pixelFont(10f));
        prompt.setForeground(Theme.TEXT_DARK);
        gc.gridy = 2;
        root.add(prompt, gc);

        JTextField nameField = new JTextField(16);
        nameField.setFont(new Font("Monospaced", Font.BOLD, 18));
        nameField.setHorizontalAlignment(SwingConstants.CENTER);
        nameField.setBackground(Theme.WHITE);
        nameField.setBorder(BorderFactory.createLineBorder(Theme.CARAMEL, 3));
        nameField.setPreferredSize(new Dimension(260, 42));
        gc.gridy = 3;
        root.add(nameField, gc);

        JLabel errorLabel = new JLabel(" ");
        errorLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        errorLabel.setForeground(Theme.CRIMSON);
        gc.gridy = 4;
        root.add(errorLabel, gc);

        JButton startButton = new JButton("START");
        startButton.setFont(Theme.pixelFont(14f));
        startButton.setBackground(Theme.ACCENT_BUTTON);
        startButton.setForeground(Theme.TEXT_DARK);
        startButton.setFocusPainted(false);
        startButton.setBorder(BorderFactory.createLineBorder(Theme.TEXT_DARK, 3));
        startButton.setPreferredSize(new Dimension(180, 50));
        gc.gridy = 5;
        root.add(startButton, gc);

        Runnable attemptStart = () -> {
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                errorLabel.setText("Every legend needs a name! Type one in.");
                return;
            }
            if (name.length() > 16) {
                errorLabel.setText("Keep it under 16 characters, champ.");
                return;
            }
            PlayerProfile profile = PlayerProfile.loadOrCreate(name);
            dispose();
            SwingUtilities.invokeLater(() -> new MainMenuFrame(profile, bank).setVisible(true));
        };

        startButton.addActionListener(e -> attemptStart.run());
        nameField.addActionListener(e -> attemptStart.run()); // Enter key also submits
    }
}
