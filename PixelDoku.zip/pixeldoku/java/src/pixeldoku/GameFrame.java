package pixeldoku;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/** The actual playable Sudoku board for one puzzle. */
public class GameFrame extends JFrame {

    private final PlayerProfile profile;
    private final PuzzleBank bank;
    private final Puzzle puzzle;
    private final int levelIndex;
    private final JTextField[][] cells = new JTextField[9][9];
    private final boolean[][] isFixed = new boolean[9][9];
    private final boolean[][] alreadyScored = new boolean[9][9];

    private final JLabel scoreLabel;
    private final JLabel statusLabel;

    // Difficulty -> (points per correct cell, hint cost) - mirrors the Python generator's bands.
    private static final java.util.Map<String, int[]> DIFFICULTY_SCORING = java.util.Map.of(
            "Sprout",        new int[]{10, 3},
            "Sapling",       new int[]{15, 4},
            "Bloom",         new int[]{20, 5},
            "Bramble",       new int[]{28, 6},
            "Ancient Grove", new int[]{40, 8}
    );

    public GameFrame(PlayerProfile profile, PuzzleBank bank, Puzzle puzzle, int levelIndex) {
        super("PixelDoku - " + puzzle.difficultyName);
        this.profile = profile;
        this.bank = bank;
        this.puzzle = puzzle;
        this.levelIndex = levelIndex;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(620, 760);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(root);

        // --- Header ---
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel(puzzle.difficultyName + " Puzzle");
        title.setFont(Theme.pixelFont(16f));
        title.setForeground(Theme.CRIMSON);
        header.add(title, BorderLayout.WEST);

        scoreLabel = new JLabel("Score: " + profile.score);
        scoreLabel.setFont(Theme.pixelFont(12f));
        scoreLabel.setForeground(Theme.TEXT_DARK);
        header.add(scoreLabel, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // --- Board ---
        JPanel board = buildBoard();
        JPanel boardWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER));
        boardWrapper.setOpaque(false);
        boardWrapper.add(board);
        root.add(boardWrapper, BorderLayout.CENTER);

        // --- Footer: hint button + status + back button ---
        JPanel footer = new JPanel();
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        footer.setOpaque(false);

        statusLabel = new JLabel(" ", SwingConstants.CENTER);
        statusLabel.setFont(new Font("SansSerif", Font.ITALIC, 13));
        statusLabel.setForeground(Theme.TEXT_DARK);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        footer.add(statusLabel);
        footer.add(Box.createVerticalStrut(10));

        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        buttonRow.setOpaque(false);

        int hintCost = DIFFICULTY_SCORING.get(puzzle.difficultyName)[1];
        JButton hintButton = new JButton("HINT (-" + hintCost + " pts)");
        styleButton(hintButton, Theme.BUBBLEGUM_PINK);
        hintButton.addActionListener(e -> giveHint());
        buttonRow.add(hintButton);

        JButton menuButton = new JButton("BACK TO MENU");
        styleButton(menuButton, Theme.WHITE);
        menuButton.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new MainMenuFrame(profile, bank).setVisible(true));
        });
        buttonRow.add(menuButton);

        footer.add(buttonRow);
        root.add(footer, BorderLayout.SOUTH);
    }

    private void styleButton(JButton button, Color bg) {
        button.setFont(Theme.pixelFont(9f));
        button.setBackground(bg);
        button.setForeground(Theme.TEXT_DARK);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Theme.TEXT_DARK, 2));
    }

    private JPanel buildBoard() {
        JPanel board = new JPanel(new GridLayout(9, 9));
        board.setBorder(BorderFactory.createLineBorder(Theme.TEXT_DARK, 4));

        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                int startVal = puzzle.start[r][c];
                JTextField field = new JTextField();
                field.setHorizontalAlignment(SwingConstants.CENTER);
                field.setFont(new Font("Monospaced", Font.BOLD, 20));

                int top = (r % 3 == 0) ? 3 : 1;
                int left = (c % 3 == 0) ? 3 : 1;
                int bottom = (r == 8) ? 3 : 1;
                int right = (c == 8) ? 3 : 1;
                field.setBorder(new MatteBorder(top, left, bottom, right, Theme.TEXT_DARK));

                if (startVal != 0) {
                    field.setText(String.valueOf(startVal));
                    field.setEditable(false);
                    field.setBackground(Theme.FIXED_CELL_BG);
                    field.setForeground(Theme.WHITE);
                    isFixed[r][c] = true;
                } else {
                    field.setBackground(Theme.EDITABLE_CELL_BG);
                    field.setForeground(Theme.TEXT_DARK);
                    ((AbstractDocument) field.getDocument()).setDocumentFilter(new SingleDigitFilter());
                    int fr = r, fc = c;
                    field.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                        public void insertUpdate(javax.swing.event.DocumentEvent e) { checkCell(fr, fc); }
                        public void removeUpdate(javax.swing.event.DocumentEvent e) { }
                        public void changedUpdate(javax.swing.event.DocumentEvent e) { }
                    });
                }
                cells[r][c] = field;
                board.add(field);
            }
        }
        return board;
    }

    /** Called whenever an editable cell's text changes; scores it once if correct. */
    private void checkCell(int r, int c) {
        String text = cells[r][c].getText().trim();
        if (text.isEmpty()) return;
        int entered = Integer.parseInt(text);
        boolean correct = entered == puzzle.solution[r][c];

        if (correct) {
            cells[r][c].setBackground(Theme.CORRECT_FLASH);
            if (!alreadyScored[r][c]) {
                alreadyScored[r][c] = true;
                int pointsPerCell = DIFFICULTY_SCORING.get(puzzle.difficultyName)[0];
                awardPoints(pointsPerCell, "Correct! +" + pointsPerCell + " pts");
            }
            checkForCompletion();
        } else {
            cells[r][c].setBackground(Theme.WRONG_FLASH);
        }
    }

    private void giveHint() {
        int[][] current = new int[9][9];
        for (int r = 0; r < 9; r++)
            for (int c = 0; c < 9; c++)
                current[r][c] = isFixed[r][c] ? puzzle.start[r][c]
                        : (cells[r][c].getText().isBlank() ? 0 : Integer.parseInt(cells[r][c].getText()));

        HintEngine.Hint hint = HintEngine.findHint(current, puzzle.solution);
        if (hint == null) {
            statusLabel.setText("Board's already full!");
            return;
        }

        cells[hint.row][hint.col].setText(String.valueOf(hint.value));
        cells[hint.row][hint.col].setBackground(Theme.SELECTED_CELL_BG);
        alreadyScored[hint.row][hint.col] = true; // hinted cells don't earn points

        int hintCost = DIFFICULTY_SCORING.get(puzzle.difficultyName)[1];
        awardPoints(-hintCost, null);

        JOptionPane.showMessageDialog(this,
                "[" + hint.technique + "]\n\n" + hint.explanation,
                "Hint - " + hint.technique,
                JOptionPane.INFORMATION_MESSAGE);

        checkForCompletion();
    }

    private void awardPoints(int delta, String statusMessage) {
        List<String> newBadges = profile.addPoints(delta);
        scoreLabel.setText("Score: " + profile.score);
        if (statusMessage != null) statusLabel.setText(statusMessage);
        for (String badge : newBadges) {
            JOptionPane.showMessageDialog(this,
                    "You unlocked a new badge:\n\n\u2605 " + badge + " \u2605",
                    "Reward Earned!", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void checkForCompletion() {
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                String text = cells[r][c].getText().trim();
                if (text.isEmpty() || Integer.parseInt(text) != puzzle.solution[r][c]) {
                    return; // not done yet
                }
            }
        }
        int bonus = DIFFICULTY_SCORING.get(puzzle.difficultyName)[0] * 3;
        awardPoints(bonus, "PUZZLE COMPLETE! +" + bonus + " bonus pts");
        JOptionPane.showMessageDialog(this,
                "You solved the " + puzzle.difficultyName + " puzzle!\nBonus: +" + bonus + " pts",
                "Level Complete!", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Restricts a text field to a single digit 1-9. */
    private static class SingleDigitFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (isValid(string)) {
                fb.remove(0, fb.getDocument().getLength());
                fb.insertString(0, string, attr);
            }
        }
        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (isValid(text)) {
                fb.remove(0, fb.getDocument().getLength());
                fb.insertString(0, text, attrs);
            }
        }
        private boolean isValid(String s) {
            return s.matches("[1-9]");
        }
    }
}
