package pixeldoku;

import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * Central place for PixelDoku's whimsical color palette and pixel font.
 * Keeping every color/font in one file means the whole game's look can
 * be re-skinned by editing exactly one place.
 */
public final class Theme {

    // --- The palette, as requested ---
    public static final Color CRIMSON        = new Color(0xDC, 0x14, 0x3C);
    public static final Color WHITE          = new Color(0xFF, 0xFF, 0xFF);
    public static final Color CARAMEL        = new Color(0xC6, 0x89, 0x58);
    public static final Color WILLOW_GREEN   = new Color(0x6C, 0x93, 0x66);
    public static final Color MATCHA         = new Color(0xB4, 0xC7, 0x9E);
    public static final Color BUBBLEGUM_PINK = new Color(0xFF, 0x9E, 0xCD);
    public static final Color BUTTER_YELLOW  = new Color(0xF5, 0xE1, 0xA4);

    // --- Derived roles, so screens stay consistent ---
    public static final Color BACKGROUND      = MATCHA;
    public static final Color PANEL_BG        = WHITE;
    public static final Color FIXED_CELL_BG   = CARAMEL;
    public static final Color EDITABLE_CELL_BG = WHITE;
    public static final Color SELECTED_CELL_BG = BUTTER_YELLOW;
    public static final Color CORRECT_FLASH   = WILLOW_GREEN;
    public static final Color WRONG_FLASH     = CRIMSON;
    public static final Color ACCENT_BUTTON   = BUBBLEGUM_PINK;
    public static final Color TEXT_DARK       = new Color(0x3A, 0x2E, 0x1F);

    private static Font pixelFontBase;

    /** Loads the real pixel font (Press Start 2P) at the given point size. */
    public static Font pixelFont(float size) {
        if (pixelFontBase == null) {
            try {
                File fontFile = new File("resources/fonts/PressStart2P-Regular.ttf");
                pixelFontBase = Font.createFont(Font.TRUETYPE_FONT, fontFile);
                GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(pixelFontBase);
            } catch (FontFormatException | IOException e) {
                // Fallback so the game still runs even if the font file is missing.
                pixelFontBase = new Font("Monospaced", Font.BOLD, 12);
            }
        }
        return pixelFontBase.deriveFont(size);
    }

    private Theme() { /* no instances */ }
}
