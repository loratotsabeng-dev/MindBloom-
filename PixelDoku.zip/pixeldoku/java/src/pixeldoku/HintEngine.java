package pixeldoku;

import java.util.*;

/**
 * Generates hints that TEACH a solving technique rather than just handing
 * over the answer - this is the "help solve puzzles more efficiently" part
 * of the brief. It looks for, in priority order:
 *   1. Naked Single  - a cell that has exactly one legal candidate left.
 *   2. Hidden Single - a candidate value that only fits in one cell within
 *                       a row, column, or box, even though that cell has
 *                       other candidates too.
 *   3. Direct Reveal - fallback for cells that need deeper techniques than
 *                       this teaching engine covers yet.
 */
public class HintEngine {

    public static class Hint {
        public final int row, col, value;
        public final String technique;
        public final String explanation;

        Hint(int row, int col, int value, String technique, String explanation) {
            this.row = row;
            this.col = col;
            this.value = value;
            this.technique = technique;
            this.explanation = explanation;
        }
    }

    /** current = player's board right now (0 = empty). solution = the answer key. */
    public static Hint findHint(int[][] current, int[][] solution) {
        Hint naked = findNakedSingle(current);
        if (naked != null) return naked;

        Hint hidden = findHiddenSingle(current);
        if (hidden != null) return hidden;

        return directReveal(current, solution);
    }

    private static Set<Integer> candidatesFor(int[][] g, int r, int c) {
        Set<Integer> candidates = new TreeSet<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
        for (int i = 0; i < 9; i++) {
            candidates.remove(g[r][i]);
            candidates.remove(g[i][c]);
        }
        int br = (r / 3) * 3, bc = (c / 3) * 3;
        for (int i = br; i < br + 3; i++)
            for (int j = bc; j < bc + 3; j++)
                candidates.remove(g[i][j]);
        return candidates;
    }

    private static Hint findNakedSingle(int[][] g) {
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                if (g[r][c] != 0) continue;
                Set<Integer> cand = candidatesFor(g, r, c);
                if (cand.size() == 1) {
                    int val = cand.iterator().next();
                    return new Hint(r, c, val, "Naked Single",
                            "Row " + (r+1) + ", Col " + (c+1) + " has only ONE possible number left: " + val
                                    + ". Every other digit is already used in its row, column, or box.");
                }
            }
        }
        return null;
    }

    private static Hint findHiddenSingle(int[][] g) {
        // Check rows
        for (int r = 0; r < 9; r++) {
            Hint h = hiddenSingleInUnit(g, cellsInRow(r), "row " + (r+1));
            if (h != null) return h;
        }
        // Check columns
        for (int c = 0; c < 9; c++) {
            Hint h = hiddenSingleInUnit(g, cellsInCol(c), "column " + (c+1));
            if (h != null) return h;
        }
        // Check boxes
        for (int b = 0; b < 9; b++) {
            int br = (b / 3) * 3, bc = (b % 3) * 3;
            Hint h = hiddenSingleInUnit(g, cellsInBox(br, bc), "this 3x3 box");
            if (h != null) return h;
        }
        return null;
    }

    private static Hint hiddenSingleInUnit(int[][] g, int[][] cells, String unitName) {
        for (int val = 1; val <= 9; val++) {
            int foundR = -1, foundC = -1, count = 0;
            for (int[] cell : cells) {
                int r = cell[0], c = cell[1];
                if (g[r][c] != 0) continue;
                if (candidatesFor(g, r, c).contains(val)) {
                    count++;
                    foundR = r;
                    foundC = c;
                }
            }
            if (count == 1) {
                return new Hint(foundR, foundC, val, "Hidden Single",
                        "In " + unitName + ", the number " + val + " can only go in Row " + (foundR+1)
                                + ", Col " + (foundC+1) + " - every other empty cell there can't take it.");
            }
        }
        return null;
    }

    private static Hint directReveal(int[][] g, int[][] solution) {
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                if (g[r][c] == 0) {
                    return new Hint(r, c, solution[r][c], "Direct Reveal",
                            "This one needs a deeper technique - here's the answer to keep you moving: "
                                    + solution[r][c] + ".");
                }
            }
        }
        return null; // board already full
    }

    private static int[][] cellsInRow(int r) {
        int[][] cells = new int[9][2];
        for (int c = 0; c < 9; c++) cells[c] = new int[]{r, c};
        return cells;
    }

    private static int[][] cellsInCol(int c) {
        int[][] cells = new int[9][2];
        for (int r = 0; r < 9; r++) cells[r] = new int[]{r, c};
        return cells;
    }

    private static int[][] cellsInBox(int br, int bc) {
        int[][] cells = new int[9][2];
        int k = 0;
        for (int i = br; i < br + 3; i++)
            for (int j = bc; j < bc + 3; j++)
                cells[k++] = new int[]{i, j};
        return cells;
    }
}
