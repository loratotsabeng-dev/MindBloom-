package pixeldoku;

import java.io.*;
import java.util.*;

/**
 * Tracks one player's progress: their gamer name, running score,
 * which difficulty levels they've unlocked, and which badges they've
 * earned. Persisted to a simple .properties file per gamer name so
 * progress survives between sessions.
 */
public class PlayerProfile {

    public final String gamerName;
    public int score;
    public int highestUnlockedLevel; // index into Difficulty.ALL
    public final Set<String> badges = new LinkedHashSet<>();

    // Score thresholds to unlock each subsequent level (index 0 always unlocked)
    private static final int[] LEVEL_UNLOCK_SCORE = {0, 50, 150, 300, 500};

    // Badge name -> score threshold at which it's earned
    private static final LinkedHashMap<String, Integer> BADGE_THRESHOLDS = new LinkedHashMap<>();
    static {
        BADGE_THRESHOLDS.put("Seedling Solver", 50);
        BADGE_THRESHOLDS.put("Grove Guardian", 150);
        BADGE_THRESHOLDS.put("Bramble Breaker", 300);
        BADGE_THRESHOLDS.put("Sudoku Sage", 500);
        BADGE_THRESHOLDS.put("PixelDoku Legend", 800);
    }

    public PlayerProfile(String gamerName) {
        this.gamerName = gamerName;
        this.score = 0;
        this.highestUnlockedLevel = 0;
    }

    private static File saveFile(String gamerName) {
        File dir = new File("saves");
        if (!dir.exists()) dir.mkdirs();
        String safeName = gamerName.replaceAll("[^a-zA-Z0-9_-]", "_");
        return new File(dir, safeName + ".properties");
    }

    /** Loads an existing profile, or creates a fresh one if none exists yet. */
    public static PlayerProfile loadOrCreate(String gamerName) {
        PlayerProfile profile = new PlayerProfile(gamerName);
        File file = saveFile(gamerName);
        if (file.exists()) {
            Properties props = new Properties();
            try (FileInputStream in = new FileInputStream(file)) {
                props.load(in);
                profile.score = Integer.parseInt(props.getProperty("score", "0"));
                profile.highestUnlockedLevel = Integer.parseInt(props.getProperty("highestUnlockedLevel", "0"));
                String badgeCsv = props.getProperty("badges", "");
                if (!badgeCsv.isBlank()) {
                    profile.badges.addAll(Arrays.asList(badgeCsv.split(",")));
                }
            } catch (IOException e) {
                System.err.println("Could not load profile, starting fresh: " + e.getMessage());
            }
        }
        return profile;
    }

    public void save() {
        Properties props = new Properties();
        props.setProperty("score", String.valueOf(score));
        props.setProperty("highestUnlockedLevel", String.valueOf(highestUnlockedLevel));
        props.setProperty("badges", String.join(",", badges));
        try (FileOutputStream out = new FileOutputStream(saveFile(gamerName))) {
            props.store(out, "PixelDoku save for " + gamerName);
        } catch (IOException e) {
            System.err.println("Could not save profile: " + e.getMessage());
        }
    }

    /** Adds points and returns any badges newly earned as a result (for celebration popups). */
    public List<String> addPoints(int points) {
        score = Math.max(0, score + points);
        List<String> newlyEarned = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : BADGE_THRESHOLDS.entrySet()) {
            if (score >= entry.getValue() && !badges.contains(entry.getKey())) {
                badges.add(entry.getKey());
                newlyEarned.add(entry.getKey());
            }
        }
        // Unlock further difficulty levels as score climbs
        for (int lvl = LEVEL_UNLOCK_SCORE.length - 1; lvl >= 0; lvl--) {
            if (score >= LEVEL_UNLOCK_SCORE[lvl]) {
                highestUnlockedLevel = Math.max(highestUnlockedLevel, lvl);
                break;
            }
        }
        save();
        return newlyEarned;
    }

    public boolean isLevelUnlocked(int levelIndex) {
        return levelIndex <= highestUnlockedLevel;
    }

    public int scoreNeededForNextLevel() {
        int next = highestUnlockedLevel + 1;
        if (next >= LEVEL_UNLOCK_SCORE.length) return -1; // maxed out
        return LEVEL_UNLOCK_SCORE[next];
    }
}
