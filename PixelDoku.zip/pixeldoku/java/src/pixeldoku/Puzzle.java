package pixeldoku;

/** One Sudoku puzzle: its starting grid and its unique solved grid. */
public class Puzzle {
    public final String difficultyName;
    public final int clueCount;
    public final int[][] start;    // 0 = empty cell
    public final int[][] solution;

    public Puzzle(String difficultyName, int clueCount, int[][] start, int[][] solution) {
        this.difficultyName = difficultyName;
        this.clueCount = clueCount;
        this.start = start;
        this.solution = solution;
    }

    public static int[][] parseGrid(String s81) {
        int[][] g = new int[9][9];
        for (int i = 0; i < 81; i++) {
            g[i / 9][i % 9] = Character.getNumericValue(s81.charAt(i));
        }
        return g;
    }
}
