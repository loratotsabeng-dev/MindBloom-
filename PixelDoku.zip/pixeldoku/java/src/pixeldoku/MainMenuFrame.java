package pixeldoku;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Level-select hub: shows the player's score, badges, and which difficulty levels they've unlocked. */
public class MainMenuFrame extends JFrame {

    public MainMenuFrame(PlayerProfile profile, PuzzleBank bank) {
        super("PixelDoku - " + profile.gamerName + "'s Grove");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(640, 560);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel();
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(new EmptyBorder(24, 24, 24, 24));
        setContentPane(root);

        JLabel welcome = new JLabel("Welcome back, " + profile.gamerName + "!");
        welcome.setFont(Theme.pixelFont(16f));
        welcome.setForeground(Theme.CRIMSON);
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);
        root.add(welcome);
        root.add(Box.createVerticalStrut(10));

        JLabel scoreLabel = new JLabel("Score: " + profile.score + " pts");
        scoreLabel.setFont(Theme.pixelFont(12f));
        scoreLabel.setForeground(Theme.TEXT_DARK);
        scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        root.add(scoreLabel);

        int neededNext = profile.scoreNeededForNextLevel();
        if (neededNext >= 0) {
            JLabel nextLabel = new JLabel((neededNext - profile.score) + " pts to unlock the next grove");
            nextLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            nextLabel.setForeground(Theme.TEXT_DARK);
            nextLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            root.add(nextLabel);
        }
        root.add(Box.createVerticalStrut(20));

        // --- Level buttons ---
        JPanel levelsPanel = new JPanel(new GridLayout(PuzzleBank.DIFFICULTY_ORDER.length, 1, 0, 10));
        levelsPanel.setOpaque(false);
        for (int i = 0; i < PuzzleBank.DIFFICULTY_ORDER.length; i++) {
            String difficultyName = PuzzleBank.DIFFICULTY_ORDER[i];
            boolean unlocked = profile.isLevelUnlocked(i);
            JButton levelButton = new JButton((unlocked ? "" : "\uD83D\uDD12 ") + "Level " + (i + 1) + ": " + difficultyName);
            levelButton.setFont(Theme.pixelFont(11f));
            levelButton.setBackground(unlocked ? Theme.ACCENT_BUTTON : Theme.WHITE);
            levelButton.setForeground(Theme.TEXT_DARK);
            levelButton.setFocusPainted(false);
            levelButton.setBorder(BorderFactory.createLineBorder(Theme.TEXT_DARK, 2));
            levelButton.setEnabled(unlocked);
            int levelIndex = i;
            levelButton.addActionListener(e -> {
                dispose();
                Puzzle puzzle = bank.randomPuzzleFor(difficultyName);
                SwingUtilities.invokeLater(() -> new GameFrame(profile, bank, puzzle, levelIndex).setVisible(true));
            });
            levelsPanel.add(levelButton);
        }
        root.add(levelsPanel);
        root.add(Box.createVerticalStrut(20));

        // --- Badge case ---
        JLabel badgeTitle = new JLabel("Badges Earned");
        badgeTitle.setFont(Theme.pixelFont(12f));
        badgeTitle.setForeground(Theme.CRIMSON);
        badgeTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        root.add(badgeTitle);
        root.add(Box.createVerticalStrut(8));

        JPanel badgePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 4));
        badgePanel.setOpaque(false);
        if (profile.badges.isEmpty()) {
            JLabel none = new JLabel("None yet - go solve something!");
            none.setFont(new Font("SansSerif", Font.ITALIC, 12));
            badgePanel.add(none);
        } else {
            for (String badge : profile.badges) {
                JLabel tag = new JLabel(" " + badge + " ");
                tag.setOpaque(true);
                tag.setBackground(Theme.WILLOW_GREEN);
                tag.setForeground(Theme.WHITE);
                tag.setFont(new Font("SansSerif", Font.BOLD, 12));
                tag.setBorder(BorderFactory.createLineBorder(Theme.TEXT_DARK, 1));
                badgePanel.add(tag);
            }
        }
        root.add(badgePanel);
    }
}
