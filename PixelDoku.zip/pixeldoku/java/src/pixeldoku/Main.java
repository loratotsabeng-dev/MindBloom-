package pixeldoku;

import javax.swing.*;

/** Entry point. Loads the puzzle bank, then shows the sign-in screen. */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                PuzzleBank bank = new PuzzleBank("resources/puzzles.txt");
                new LoginFrame(bank).setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                        "Could not load puzzles.txt - make sure you run PixelDoku from the\n"
                                + "project root folder so 'resources/puzzles.txt' can be found.\n\n"
                                + "Error: " + e.getMessage(),
                        "Startup Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
