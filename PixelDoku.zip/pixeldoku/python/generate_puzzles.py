"""
PixelDoku Puzzle Forge
------------------------
Generates a bank of Sudoku puzzles with guaranteed unique solutions,
graded by difficulty (clue count + logical technique required),
and writes them out to a simple pipe-delimited text file that the
Java game reads at runtime.

Format of puzzles.txt (one puzzle per line):
    difficulty|clue_count|puzzle_81_chars|solution_81_chars

'0' represents an empty cell in the puzzle string.
"""

import random
import json

SIZE = 9
BOX = 3


def make_solved_grid():
    """Build a fully solved 9x9 grid using randomized backtracking."""
    grid = [[0] * SIZE for _ in range(SIZE)]

    def valid(g, r, c, val):
        if val in g[r]:
            return False
        if val in [g[i][c] for i in range(SIZE)]:
            return False
        br, bc = (r // BOX) * BOX, (c // BOX) * BOX
        for i in range(br, br + BOX):
            for j in range(bc, bc + BOX):
                if g[i][j] == val:
                    return False
        return True

    def fill(g, pos=0):
        if pos == SIZE * SIZE:
            return True
        r, c = divmod(pos, SIZE)
        nums = list(range(1, 10))
        random.shuffle(nums)
        for val in nums:
            if valid(g, r, c, val):
                g[r][c] = val
                if fill(g, pos + 1):
                    return True
                g[r][c] = 0
        return False

    fill(grid)
    return grid


def count_solutions(grid, limit=2):
    """Count solutions up to `limit` (we only need to know if it's >1)."""
    g = [row[:] for row in grid]
    count = 0

    def valid(r, c, val):
        if val in g[r]:
            return False
        if val in [g[i][c] for i in range(SIZE)]:
            return False
        br, bc = (r // BOX) * BOX, (c // BOX) * BOX
        for i in range(br, br + BOX):
            for j in range(bc, bc + BOX):
                if g[i][j] == val:
                    return False
        return True

    def solve(pos=0):
        nonlocal count
        if count >= limit:
            return
        if pos == SIZE * SIZE:
            count += 1
            return
        r, c = divmod(pos, SIZE)
        if g[r][c] != 0:
            solve(pos + 1)
            return
        for val in range(1, 10):
            if valid(r, c, val):
                g[r][c] = val
                solve(pos + 1)
                g[r][c] = 0
                if count >= limit:
                    return

    solve()
    return count


def make_puzzle(solved_grid, target_clues):
    """Remove cells one at a time, only keeping a removal if the puzzle
    still has a UNIQUE solution. Stops once target_clues is reached
    or no more cells can be safely removed."""
    puzzle = [row[:] for row in solved_grid]
    cells = [(r, c) for r in range(SIZE) for c in range(SIZE)]
    random.shuffle(cells)

    clues_remaining = SIZE * SIZE
    for (r, c) in cells:
        if clues_remaining <= target_clues:
            break
        backup = puzzle[r][c]
        puzzle[r][c] = 0
        if count_solutions(puzzle, limit=2) == 1:
            clues_remaining -= 1
        else:
            puzzle[r][c] = backup  # revert, removal broke uniqueness

    return puzzle, clues_remaining


def grid_to_string(grid):
    return "".join(str(grid[r][c]) for r in range(SIZE) for c in range(SIZE))


# Difficulty bands: (name, target clue count, points_per_correct_cell, hint_penalty)
DIFFICULTIES = [
    ("Sprout", 42, 10, 3),      # Level 1 - very easy, lots of clues
    ("Sapling", 36, 15, 4),     # Level 2
    ("Bloom", 30, 20, 5),       # Level 3
    ("Bramble", 26, 28, 6),     # Level 4 - hard
    ("Ancient Grove", 22, 40, 8),  # Level 5 - expert
]

PUZZLES_PER_DIFFICULTY = 8


def main():
    random.seed()  # true randomness each generation run
    lines = []
    manifest = []

    for name, clues, points, hint_cost in DIFFICULTIES:
        made = 0
        attempts = 0
        while made < PUZZLES_PER_DIFFICULTY and attempts < PUZZLES_PER_DIFFICULTY * 6:
            attempts += 1
            solved = make_solved_grid()
            puzzle, actual_clues = make_puzzle(solved, clues)
            # accept if we got reasonably close to target clue count
            if actual_clues <= clues + 4:
                lines.append(f"{name}|{actual_clues}|{grid_to_string(puzzle)}|{grid_to_string(solved)}")
                made += 1
        manifest.append({"name": name, "puzzle_count": made, "points_per_cell": points, "hint_cost": hint_cost})
        print(f"{name}: generated {made} puzzles (target clues={clues})")

    with open("puzzles.txt", "w") as f:
        f.write("\n".join(lines) + "\n")

    with open("difficulty_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)

    print(f"\nDone. Wrote {len(lines)} puzzles to puzzles.txt")


if __name__ == "__main__":
    main()
