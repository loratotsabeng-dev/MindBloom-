# PixelDoku 🌿🍬 — a whimsical, technique-teaching Sudoku quest

PixelDoku is a two-language desktop game: a **Python** puzzle forge generates
a graded bank of Sudoku puzzles with mathematically guaranteed unique
solutions, and a **Java (Swing)** front end lets a signed-in player solve
them, earn points, unlock harder "groves," and collect badges — with a hint
system that *teaches solving technique* instead of just handing over answers.

| Login | Level Select | Gameplay |
|---|---|---|
| ![Login](java/screenshots/login.png) | ![Menu](java/screenshots/menu.png) | ![Board](java/screenshots/board.png) |

## Why two languages
This mirrors a real production pattern: a Python service does the
computationally-heavy, math-oriented offline work (generating puzzles,
proving uniqueness via backtracking + solution-counting), and hands off a
clean, simple data file to a separate application layer (Java/Swing) that
owns the interactive experience. It's the same "batch job feeds a live app"
shape as a lot of real backend/frontend or data-pipeline/product splits.

## Features
- **Sign-in flow** — enter a gamer name, profile is created/loaded automatically
- **Persistent player profiles** — score, unlocked levels, and badges saved to disk between sessions
- **5 graded difficulty levels** (Sprout → Sapling → Bloom → Bramble → Ancient Grove), each with its own point value and hint cost
- **Guaranteed-unique puzzles** — the Python generator verifies uniqueness via a solution-counting backtracker before accepting a puzzle into the bank
- **Technique-teaching hint engine** — rather than a plain reveal, hints look for a **Naked Single** or **Hidden Single** first and explain *why* the cell must be that value, falling back to a direct reveal only when needed
- **Point system starting at 0** — points for correct entries, a completion bonus, a small deduction for using hints
- **Reward system** — 5 badges unlock at score milestones, which also gate access to harder levels
- **Custom color theme** — crimson, white, caramel, willow green, matcha, bubblegum pink, and butter yellow, centralized in one `Theme.java` file
- **Real pixel font** — Press Start 2P, embedded and loaded at runtime (not just a monospace approximation)

## Architecture
```
pixeldoku/
├── python/
│   └── generate_puzzles.py     # generates puzzles.txt (puzzle bank)
├── java/
│   ├── src/pixeldoku/
│   │   ├── Main.java           # entry point
│   │   ├── LoginFrame.java     # sign-in screen
│   │   ├── MainMenuFrame.java  # level select + badge case
│   │   ├── GameFrame.java      # the 9x9 board itself
│   │   ├── HintEngine.java     # Naked Single / Hidden Single logic
│   │   ├── PuzzleBank.java     # loads & serves puzzles by difficulty
│   │   ├── Puzzle.java         # puzzle data holder
│   │   ├── PlayerProfile.java  # score, badges, save/load
│   │   └── Theme.java          # color palette + pixel font
│   ├── resources/
│   │   ├── puzzles.txt         # generated puzzle bank (40 puzzles)
│   │   ├── difficulty_manifest.json
│   │   └── fonts/PressStart2P-Regular.ttf
│   └── screenshots/
└── README.md
```

## How to run

**Requirements:** JDK 17+ (tested on OpenJDK 21), Python 3.8+ (only needed if you want to regenerate the puzzle bank)

```bash
# 1. (Optional) regenerate the puzzle bank
cd python
python3 generate_puzzles.py
cp puzzles.txt difficulty_manifest.json ../java/resources/

# 2. Compile the game
cd ../java
javac -d out src/pixeldoku/*.java

# 3. Run it — must be run from the java/ folder so resources/ can be found
java -cp out pixeldoku.Main
```

## Scoring & rewards
| Difficulty | Points per correct cell | Hint cost | Unlocks at score |
|---|---|---|---|
| Sprout | 10 | -3 | 0 (always open) |
| Sapling | 15 | -4 | 50 |
| Bloom | 20 | -5 | 150 |
| Bramble | 28 | -6 | 300 |
| Ancient Grove | 40 | -8 | 500 |

Badges: **Seedling Solver** (50) → **Grove Guardian** (150) → **Bramble Breaker** (300) → **Sudoku Sage** (500) → **PixelDoku Legend** (800)

## Design decisions worth knowing (for interview conversations)
- **Why generate puzzles offline in Python instead of at runtime in Java?** Proving a Sudoku puzzle has a unique solution requires a full solution-count backtrack, which is too slow to do live every time a player requests a puzzle. Generating a bank ahead of time trades a slower one-time batch job for instant in-game puzzle loading.
- **Why a technique-teaching hint engine instead of a plain reveal?** A reveal-only hint stops someone from ever getting better at Sudoku; teaching Naked/Hidden Singles gives them a transferable skill and directly serves the brief's "help solve puzzles more efficiently" goal.
- **Why `.properties` files instead of a database for save data?** At this scale (one local player profile per gamer name), a database is unnecessary overhead. This is a deliberate scope decision, documented rather than left implicit — the same kind of tradeoff call a real engineer has to justify.

## Ideas for extending this further
- Add more logical techniques to the hint engine (Pointing Pairs, X-Wing)
- Add a timer + speed bonus
- Migrate save data to SQLite for multi-device sync
- Add a leaderboard (ties in nicely with a Postgres/AWS RDS backend, same pattern as the Kgolo Culture project)

## License
MIT — see `LICENSE`.
